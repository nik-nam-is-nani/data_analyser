DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': 'defaultdb',
        'USER': 'avnadmin',
        'PASSWORD': 'AVNS_QzflMrR3BXGAgudXgwL',  # replace with revealed password
        'HOST': 'pg-7fabea4-nikshithkyathrigi2005-3753.g.aivencloud.com',
        'PORT': '14586',
        'OPTIONS': {
            'sslmode': 'require',
        },
    }
}
